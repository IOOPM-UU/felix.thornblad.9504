package org.ioopm.calculator.ast;

public class Addition extends Binary{
       public Addition (final SymbolicExpression lhs, final SymbolicExpression rhs){
          super("Addition", lhs, rhs);
           //int i=Integer.parseInt(s); 
         
           //evaluateExpression
       }
}