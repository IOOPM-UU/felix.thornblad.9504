package org.ioopm.calculator.ast;

public class Cos extends Unary {
    public Cos(final SymbolicExpression lhs){
        super("Cos",lhs);
    } 
}