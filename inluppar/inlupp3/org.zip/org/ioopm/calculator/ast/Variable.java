package org.ioopm.calculator.ast;

public class Variable extends Atom {
    public Variable (final String id){
        super("Variable",(id));
    }
}