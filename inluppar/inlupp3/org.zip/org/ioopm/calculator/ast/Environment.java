package org.ioopm.calculator.ast;
// public class Environment extends HashMap<Variable, SymbolicExpression> {}
        public class Environment {
            public Environment(){
                
            }
        }