import org.ioopm.calculator.ast.*;
import org.ioopm.calculator.parser.*;
import java.util.Scanner;

public class Calculator {
    public static void main(String [] args) {
        System.out.println("Wdawd");
    }
}